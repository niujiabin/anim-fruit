﻿
/**
 * 技能模块
 */
export default class SkillModule {
    private static _instance: SkillModule = new SkillModule();
    public static GetInstance() {
        return this._instance;
    }

    //生成技能
    static GenerateSkill(player: Gameplay.Player, skillInfo: void) {
        
        

    }
}