﻿import GameDataServer from "../Cache/GameDataServer";
import SkillConfig from "../Config/SkillConfig";
import PlayerInfo from "../entity/PlayerInfo";
import SkillInfo from "../entity/SkillInfo";
import SkillModule from "./SkillModule";


export default class PlayerModule {

    private static _instance: PlayerModule = new PlayerModule();
    public static GetInstance() {
        return this._instance;
    }

    public Init() {

        DataStorage.setTemporaryStorage(SystemUtil.isPIE)
    
        //玩家进入游戏
        Events.addPlayerJoinedListener((player)=>{

        })

        //玩家离开游戏
        Events.addPlayerLeftListener((player)=>{

        })

    }

    /**
     * 切换装备技能
     */
    public SwitchEquipSkill(player:Gameplay.Player)
    {

    }

    /**
     * 装备技能
     */
    public EquipSkill(player:Gameplay.Player)
    {

    }

    /**
     * 卸下技能
     */
    public UnEquipSkill(player:Gameplay.Player)
    {

    }
}