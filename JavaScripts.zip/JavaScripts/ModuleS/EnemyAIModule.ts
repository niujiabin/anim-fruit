﻿import EnemyConfig from "../Config/EnemyConfig";
import EnemyInfo from "../entity/EnemyInfo";

/**
 * 敌人AI模块
 */
export default class EnemyAIModule {

    public allEnemyAnchoreFolder;

    private static _instance: EnemyAIModule = new EnemyAIModule();

    /**
     * 对象池，key怪物所在区域  
     * value 怪物列表
     */
    public static EnemiesPool:Map<string, Array<EnemyInfo>> = new Map<string, Array<EnemyInfo>>()

    public static GetInstance() {
        return this._instance;
    }

    /**
     * 
     */
    public async Init()
    {   

        //初始化变量
        await this.InitObj()

        //服务器逻辑
        if(SystemUtil.isServer())
        {
            //生成怪物对象，一段时间把当前地图的怪物同步给当前区域玩家
            //服务器需要创建所有敌人对象
            this.InitServerEnemy()
        }
        //客户端逻辑
        else
        {
            //客户端生成怪物实体
            this.InitClientEnemy()
        }
    }
    async InitObj() {
        this.allEnemyAnchoreFolder = await Core.GameObject.asyncFind("2391765D");
    }
    /**
     * 初始化客户端怪物信息
     */
    InitClientEnemy() {
        this.allEnemyAnchoreFolder.getChildren().forEach((enemyArea)=>{
            //获取地图区域

            //根据地图区域创建敌方怪物信息
            enemyArea.getChildren().forEach((enemySpawnPoint)=>{
                let enemyInfo:EnemyInfo = new EnemyInfo()
                enemyInfo.worldPositionX = enemySpawnPoint.worldLocation.x
                enemyInfo.worldPositionY = enemySpawnPoint.worldLocation.y
                console.log("客户端创建敌人信息" + JSON.stringify(enemyInfo))

                Core.GameObject.asyncSpawn({
                    guid:EnemyConfig.allEnemy[0].prefabAssetID,
                    replicates:true
                }).then((enemyPrefab)=>{
                    let npc = enemyPrefab.getChildByName("Character") as Gameplay.NPC
                    npc.worldLocation = enemySpawnPoint.worldLocation
                    console.log(npc.worldLocation)
                })
            })
        })
    }
    /**
     * 初始化服务器端敌人对象
     */
    InitServerEnemy() {
        this.allEnemyAnchoreFolder.getChildren().forEach((enemyArea)=>{
            if(!EnemyAIModule.EnemiesPool.has(enemyArea))
            {
                EnemyAIModule.EnemiesPool.set(enemyArea, new Array<EnemyInfo>())
            }
            enemyArea.getChildren().forEach((enemySpawnPoint)=>{
                let enemyInfo:EnemyInfo = new EnemyInfo()
                enemyInfo.worldPositionX = enemySpawnPoint.worldLocation.x
                enemyInfo.worldPositionY = enemySpawnPoint.worldLocation.y
                console.log("服务器创建敌人信息" + JSON.stringify(enemyInfo))
                //向集合添加敌人
                EnemyAIModule.EnemiesPool.get(enemyArea).push(enemyInfo)
            })
        })
    }

    /**
     * 敌人被打死
     */
    public die()
    {

    }
    /**
     * 怪物重新复活
     */
    public reSpawn()
    {

    }

}