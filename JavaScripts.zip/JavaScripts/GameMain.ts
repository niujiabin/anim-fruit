﻿import EnemyAIModule from "./ModuleS/EnemyAIModule";

@Core.Class
export default class GameMain extends Core.Script {

    /** 当脚本被实例后，会在第一帧更新前调用此函数 */
    protected onStart(): void {

        EnemyAIModule.GetInstance().Init()

        if(SystemUtil.isServer())
        {
            
        }
        else
        {
            // Core.GameObject.asyncFind("10D8913B").then((Area_1_List)=>{
            //     let allnpc = Area_1_List.getChildren()
            //     allnpc.forEach((npc:Gameplay.NPC)=>{
            //        npc.ready().then(()=>{
            //         let locationA = new Type.Vector(306.990,-958.060,41.000);
            //         //执行moveto函数
            //         Gameplay.moveTo(npc, locationA)3
            //        })
            //     })
            // })
        }
    }

    /**
     * 周期函数 每帧执行
     * 此函数执行需要将this.useUpdate赋值为true
     * @param dt 当前帧与上一帧的延迟 / 秒
     */
    protected onUpdate(dt: number): void {

    }

    /** 脚本被销毁时最后一帧执行完调用此函数 */
    protected onDestroy(): void {

    }
}