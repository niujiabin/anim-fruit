﻿

/**
 * 物品
 */
export default class Item  {

}