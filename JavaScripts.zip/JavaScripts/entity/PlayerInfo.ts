﻿import Item from "./Item"

/**
 * 角色信息
 */
export default class PlayerInfo {
    /**
     * 等级
     */
    public level:number = 1
    /**
     * 经验值
     */
    public exp:number = 0
    /**
     * 阵营
     */
    public camp:string = ""
    /**
     * 金钱
     */
    public money:number = 0
    /**
     * 生命
     */
    public health:number = 0
    /**
     * 能量
     */
    public energy:number = 0
    /**
     * 拳击能力点
     */
    public punchPower:number = 0
    /**
     * 防御能力点
     */
    public defensePower:number = 0
    /**
     * 剑能力点
     */
    public swordPower:number = 0
    /**
     * 变身水果能力点
     */
    public fruitPower:number = 0
    /**
     * 物品列表
     */
    public itemList:Array<Item> = new Array<Item>();
    /**
     * 装备信息
     */

}