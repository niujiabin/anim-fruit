﻿
/**
 * 技能信息
 */
export default class SkillInfo{

   
}