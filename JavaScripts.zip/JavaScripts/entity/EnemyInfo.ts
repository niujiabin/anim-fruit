﻿
/**
 * 敌人信息
 */
export default class EnemyInfo {

    public id:string = ""

    public name:string
    /**
     * 等级
     */
    public level:number 
    /**
     * 攻击力
     */
    public attack:number
    /**
     * 所属地图ID
     */
    public belongMapId:string
    /**
     * 移动速度
     */
    public moveSpeed:number = 0
    /**
     * 世界坐标X
     */
    public worldPositionX:number = 0
    /**
     * 世界坐标Y
     */
    public worldPositionY:number = 0



}