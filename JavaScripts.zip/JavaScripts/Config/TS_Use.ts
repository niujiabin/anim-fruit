﻿
@Core.Class
export default class TS_Use extends Core.Script {

    // // 使用自定义类型:
    // type Direction = 'up' | 'down' | 'left' | 'right'

    // function changeDirection(direction: Direction) {
    // console.log(direction)
    // }

    // // 调用函数时，会有类型提示：
    // changeDirection('up')

    // type Gender = '男' | '女'
    // let gender: Gender = '男'
    // gender = '女'
}