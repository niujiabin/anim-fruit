﻿/**
 * 敌方配置信息
 */
export default class EnemyConfig  {
    
    public static allEnemy:any = [{
        id : "1001",
        name : "普通怪物",
        prefabAssetID : "528A3D7841FB0D14544DF09D0D21663A",
        attack : 10,
        moveSpeed : 20,
    }]
}